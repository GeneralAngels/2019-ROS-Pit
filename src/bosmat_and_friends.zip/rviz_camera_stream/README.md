# rviz_camera_stream

Custom rviz camera plugin that publishes rendered camera video stream
